#ifndef mega2560setup
#define mega2560setup

void setupATmegaPorts(int Daybreak);

void adcInit(void);

void setupTimer3(void);

#endif